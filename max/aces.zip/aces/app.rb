require "sinatra"

get "/" do 

	erb :starter
end